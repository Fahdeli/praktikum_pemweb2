<?php
$nomor_looping = 0;
do {
    echo 'ini adalah looping ke-' . $nomor_looping . '<br>';
    $nomor_looping++;
}while ($nomor_looping < 10);