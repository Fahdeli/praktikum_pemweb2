<?php
$nasi = 'ditumbuk';

if($nasi == 'digoreng'){
    echo ' ya, nasi di goreng';
} elseif ($nasi == 'dibakar'){
    echo 'ya, nasi dibakar';
} else{
    echo 'ya, ini nasi bubur';
}

