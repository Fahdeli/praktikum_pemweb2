<?php

function hitungLuasPersegi($sisi){
    echo $sisi * $sisi;
}

