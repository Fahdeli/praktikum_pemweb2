<?php

echo "Nama file :" . $_SERVER['PHP_SELF'];