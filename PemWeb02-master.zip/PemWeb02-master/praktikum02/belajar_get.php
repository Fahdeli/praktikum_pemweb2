<?php
$nama = $_GET['nama'];
$jenis_kelamin = $_GET['jenis_kelamin'];
$matkul = $_GET['matkul'];
$nomor_telepon = $_GET['nomor_telpon'];


echo '<h1>Form pendaftaran mahasiwa</h1> <br>';
echo 'nama:' . $nama . '<br>';
echo 'jenis kelamin: ' . $jenis_kelamin . '<br>';
echo 'mata kuliah: ' . $matkul . '<br>';
echo 'nomor telepon: ' . $nomor_telepon . '<br>';