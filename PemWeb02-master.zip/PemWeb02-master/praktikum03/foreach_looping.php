<?php
$array = ['kucing','anjing','kuda','kapibara','kumbang'];
foreach($array as $key => $value){
    echo 'index ke-' . $key . ' adalah ' . $value . '<br>'; 
}