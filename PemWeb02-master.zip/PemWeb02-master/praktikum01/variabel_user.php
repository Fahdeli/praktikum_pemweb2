<?php
$nama = "Dimas Aji Nugroho";
$prodi = "Sistem Informasi";
$IPK = 4.00;

echo "nama saya adalah " . $nama . "<br>";
echo "Program studi $prodi <br>";
echo "IPK saya $IPK ,aamiin <br>";