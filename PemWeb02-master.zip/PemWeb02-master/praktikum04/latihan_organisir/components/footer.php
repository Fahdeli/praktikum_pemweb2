<footer class="footer bottom-0 text-center mt-auto bg-dark"> 
        <div class="mx-4 mt-3">
            <p class="small text-white">
                CopyLeft 20232 - created with <i class="fas fa-heart text-danger"></i> by you, yes you !!
            </p>
        </div>
</footer>