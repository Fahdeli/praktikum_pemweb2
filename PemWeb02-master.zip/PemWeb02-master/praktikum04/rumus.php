<?php

function hitungLuasPersegiPanjang($panjang,$lebar){
    echo $panjang * $lebar;
}

function hitungLuasLingkaran($jariJari){
    define('PHI',3.14);
    echo PHI * $jariJari * $jariJari;
}

