<?php
//cara pertama untuk membuat konstanta
const PRODI = "Desain Komunikasi Visual";

//cara kedua dengan memasukkan fungsi define 
define ("NAMA","Dimas Aji Nugroho");
echo PRODI . "<br>";
echo NAMA;
