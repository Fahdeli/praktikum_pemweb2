<?php
$nama = $_POST['nama'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$matkul = $_POST['matkul'];
$nomor_telepon = $_POST['nomor_telpon'];


echo '<h1>Form pendaftaran mahasiwa</h1> <br>';
echo 'nama:' . $nama . '<br>';
echo 'jenis kelamin: ' . $jenis_kelamin . '<br>';
echo 'mata kuliah: ' . $matkul . '<br>';
echo 'nomor telepon: ' . $nomor_telepon . '<br>';