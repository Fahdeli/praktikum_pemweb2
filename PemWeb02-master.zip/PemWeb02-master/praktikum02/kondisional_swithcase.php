<?php
$bahan = 'bawang';

switch($bahan) {
    case 'terasi':
        echo 'sambal terasi';
        break;
    case 'cabo':
        echo 'sambal cabo';
        break;
    case 'bawang':
        echo 'sambel bawang';
        break;
    default:
        echo 'sambal tomat';
        break;    
}