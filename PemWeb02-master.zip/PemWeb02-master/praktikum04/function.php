<?php

include "library.php";
require "rumus.php";

hitungLuasPersegi(20);

echo "<br>";

hitungLuasPersegiPanjang(20,10);

echo "<br>";

hitungLuasLingkaran(10);
