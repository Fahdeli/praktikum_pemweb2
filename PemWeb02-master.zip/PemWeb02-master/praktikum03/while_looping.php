<?php
$nomor_looping = 0;
while($nomor_looping < 10){
    echo "looping ke-" . $nomor_looping . '<br>';
    $nomor_looping++;
} 